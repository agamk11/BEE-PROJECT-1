let arr=[1,2];
let ans=arr.filter(()=>{
    return ;
})
console.log(ans)